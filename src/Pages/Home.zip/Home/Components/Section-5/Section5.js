import React from "react";

const Section5 = () => {
  return (
    <section className="section5">
      <h5>Agriculture Products</h5>
      <h5>Projects Completed</h5>
      <h5>Satisfied Clients</h5>
      <h5>Experts Farmers</h5>
    </section>
  );
};

export default Section5;
