import React from "react";
import { FaShoppingCart } from "react-icons/fa";
const Header = (props) => {
  return (
    <>
        <div className="header">
          <div className="header-list">
            <button onClick={()=> props.handleShow(true)}>
            <FaShoppingCart size={25} />
            <sup>{props.count}</sup>
            </button>
            {/* <FaShoppingCart size={25} /> */}
            {/* <sup>{props.count}</sup> */}
          </div>
        </div>
          </>
  );
};

export default Header;
